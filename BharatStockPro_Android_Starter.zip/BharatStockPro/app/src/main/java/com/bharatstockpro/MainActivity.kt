package com.bharatstockpro

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Ink = Color(0xFF101827)
private val Panel = Color(0xFF1B2638)
private val Green = Color(0xFF25C685)
private val Red = Color(0xFFFF6577)
private val Muted = Color(0xFF9BA9BC)

data class Stock(val name: String, val symbol: String, val price: String, val change: String, val positive: Boolean)
val sampleStocks = listOf(
    Stock("Reliance Industries", "RELIANCE", "₹1,284.50", "+1.42%", true),
    Stock("HDFC Bank", "HDFCBANK", "₹1,742.30", "+0.86%", true),
    Stock("Tata Consultancy Services", "TCS", "₹3,912.00", "-0.34%", false),
    Stock("ICICI Bank", "ICICIBANK", "₹1,298.75", "+1.08%", true),
    Stock("Infosys", "INFY", "₹1,536.20", "-0.62%", false),
    Stock("State Bank of India", "SBIN", "₹812.40", "+0.51%", true)
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { BharatApp() }
    }
}

@Composable
fun BharatApp() {
    var tab by remember { mutableStateOf("Home") }
    var query by remember { mutableStateOf("") }
    var watchlist by remember { mutableStateOf(setOf("RELIANCE", "HDFCBANK")) }
    MaterialTheme(colorScheme = darkColorScheme(
        background = Ink, surface = Panel, primary = Green,
        onBackground = Color.White, onSurface = Color.White
    )) {
        Scaffold(
            containerColor = Ink,
            bottomBar = {
                NavigationBar(containerColor = Panel) {
                    listOf("Home", "Markets", "Watchlist", "Portfolio", "News").forEach { item ->
                        NavigationBarItem(
                            selected = tab == item,
                            onClick = { tab = item },
                            icon = {
                                Icon(
                                    when(item) {
                                        "Home" -> Icons.Default.Home
                                        "Markets" -> Icons.Default.ShowChart
                                        "Watchlist" -> Icons.Default.Star
                                        "Portfolio" -> Icons.Default.AccountBalanceWallet
                                        else -> Icons.Default.Article
                                    }, contentDescription = item
                                )
                            },
                            label = { Text(item, fontSize = 10.sp) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = Green, selectedTextColor = Green,
                                indicatorColor = Ink, unselectedIconColor = Muted,
                                unselectedTextColor = Muted
                            )
                        )
                    }
                }
            }
        ) { padding ->
            Column(Modifier.fillMaxSize().padding(padding).padding(horizontal = 18.dp)) {
                Spacer(Modifier.height(18.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("BHARAT STOCK PRO", color = Green, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        Text(tab, color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Bold)
                    }
                    Surface(color = Panel, shape = RoundedCornerShape(50)) {
                        Text("🇮🇳  NSE • BSE", Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                            color = Muted, fontSize = 11.sp)
                    }
                }
                Spacer(Modifier.height(16.dp))
                when(tab) {
                    "Home" -> HomeScreen()
                    "Markets" -> MarketsScreen()
                    "Watchlist" -> {
                        OutlinedTextField(
                            value = query, onValueChange = { query = it },
                            modifier = Modifier.fillMaxWidth(),
                            placeholder = { Text("Search stocks…", color = Muted) },
                            leadingIcon = { Icon(Icons.Default.Search, null) },
                            singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = Color.White, unfocusedTextColor = Color.White,
                                focusedBorderColor = Green, unfocusedBorderColor = Panel
                            )
                        )
                        Spacer(Modifier.height(12.dp))
                        LazyColumn {
                            items(sampleStocks.filter {
                                it.symbol.contains(query, true) || it.name.contains(query, true)
                            }) { stock ->
                                StockRow(stock, watchlist.contains(stock.symbol)) {
                                    watchlist = if (watchlist.contains(stock.symbol))
                                        watchlist - stock.symbol else watchlist + stock.symbol
                                }
                            }
                        }
                    }
                    "Portfolio" -> PlaceholderScreen("Your portfolio", "Add holdings to track your investment value and profit/loss.")
                    "News" -> PlaceholderScreen("Market news", "Connect a licensed news/data provider to show verified market headlines.")
                }
            }
        }
    }
}

@Composable
fun HomeScreen() {
    Text("MARKET SNAPSHOT", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold)
    Spacer(Modifier.height(10.dp))
    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        IndexCard("NIFTY 50", "24,350.25", "+0.72%", true, Modifier.weight(1f))
        IndexCard("SENSEX", "80,125.40", "+0.65%", true, Modifier.weight(1f))
    }
    Spacer(Modifier.height(10.dp))
    IndexCard("BANK NIFTY", "52,410.80", "-0.18%", false, Modifier.fillMaxWidth())
    Spacer(Modifier.height(20.dp))
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text("POPULAR STOCKS", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
        Text("DEMO DATA", color = Color(0xFFFFC46B), fontSize = 10.sp, fontWeight = FontWeight.Bold)
    }
    Spacer(Modifier.height(8.dp))
    sampleStocks.take(4).forEach { StockRow(it, false) {} }
    Spacer(Modifier.height(10.dp))
    Text("Signals are educational indicators only — not investment advice.", color = Muted, fontSize = 10.sp)
}

@Composable
fun IndexCard(title: String, price: String, change: String, positive: Boolean, modifier: Modifier = Modifier) {
    Surface(modifier, color = Panel, shape = RoundedCornerShape(18.dp)) {
        Column(Modifier.padding(16.dp)) {
            Text(title, color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            Text(price, color = Color.White, fontSize = 21.sp, fontWeight = FontWeight.Bold)
            Text(change, color = if (positive) Green else Red, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
        }
    }
}

@Composable
fun StockRow(stock: Stock, saved: Boolean, onToggle: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(vertical = 7.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(stock.name, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
            Text(stock.symbol, color = Muted, fontSize = 11.sp)
        }
        Column(horizontalAlignment = Alignment.End) {
            Text(stock.price, color = Color.White, fontWeight = FontWeight.SemiBold)
            Text(stock.change, color = if (stock.positive) Green else Red, fontSize = 12.sp)
        }
        if (onToggle !== {}) {
            IconButton(onClick = onToggle) {
                Icon(if (saved) Icons.Default.Star else Icons.Default.StarBorder, null,
                    tint = if (saved) Color(0xFFFFC46B) else Muted)
            }
        }
    }
    HorizontalDivider(color = Panel)
}

@Composable
fun MarketsScreen() {
    Text("INDIAN INDICES", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold)
    Spacer(Modifier.height(12.dp))
    listOf(
        Triple("NIFTY 50", "24,350.25", "+0.72%"),
        Triple("SENSEX", "80,125.40", "+0.65%"),
        Triple("BANK NIFTY", "52,410.80", "-0.18%"),
        Triple("NIFTY IT", "38,220.10", "+0.31%")
    ).forEach { (name, value, change) ->
        Surface(color = Panel, shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth().padding(bottom = 9.dp)) {
            Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(name, Modifier.weight(1f), color = Color.White, fontWeight = FontWeight.Bold)
                Column(horizontalAlignment = Alignment.End) {
                    Text(value, color = Color.White)
                    Text(change, color = if (change.startsWith("+")) Green else Red, fontSize = 12.sp)
                }
            }
        }
    }
    Text("Prices shown are illustrative demo values, not live quotes.", color = Muted, fontSize = 11.sp)
}

@Composable
fun PlaceholderScreen(title: String, body: String) {
    Surface(color = Panel, shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(20.dp)) {
            Text(title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Spacer(Modifier.height(8.dp))
            Text(body, color = Muted, fontSize = 13.sp)
        }
    }
}
