# Bharat Stock Pro (Android starter)

A native Android app starter built with Kotlin + Jetpack Compose.

## Included
- Dark-mode dashboard
- NSE/BSE index overview cards
- Stock list and searchable watchlist UI
- Portfolio and news starter screens
- Clearly labelled illustrative demo values

## Important: market data
This starter does **not** display live market data. The figures in the UI are illustrative placeholders and must not be used for trading decisions.

For production live prices, use a licensed data/broker provider and follow its exchange display and redistribution terms. NSE describes its real-time data products and subscription process here:
https://www.nse.in/static/market-data/real-time-data-subscription

Possible broker API route: Zerodha Kite Connect (requires account/API setup; live WebSocket data is on its paid Connect tier):
https://zerodha.com/products/api/

Never put provider secrets or broker API secrets directly in the Android app. Use a secure backend to authenticate and proxy requests. Before publishing, implement provider-specific authentication, error handling, data timestamps, rate limits, privacy policy, and required licensing.

## Open in Android Studio
1. Install Android Studio (current stable).
2. Choose **Open** and select this folder.
3. Let Gradle sync complete.
4. Run on an Android device or emulator.

## Next development steps
1. Add a backend and licensed NSE/BSE data provider.
2. Replace `sampleStocks` and index placeholders with API responses.
3. Add historical OHLC charting, RSI/MACD calculations, and timestamps.
4. Add persistent watchlist/portfolio storage.
5. Add alerts and news provider integration.

## Financial safety
BUY/SELL/HOLD indicators should be presented as educational research signals, not guaranteed predictions or personalized financial advice. Do not execute orders in this starter.
